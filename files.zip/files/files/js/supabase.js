/* =========================================================================
   supabase.js
   Настоящее подключение к Supabase + описание всех backend-функций.
   Сейчас USE_MOCKS = true, поэтому все функции читают/пишут в mock-data.js
   (localStorage). Чтобы подключить реальный бэкенд:
     1) Вставьте SUPABASE_URL и SUPABASE_ANON_KEY.
     2) Поставьте USE_MOCKS = false.
     3) Создайте таблицы (см. SQL-схему в комментарии внизу файла).
   ========================================================================= */

const SUPABASE_URL = 'https://paeipdqlwaxtsriwgjjk.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_Gx3foPgEAfrcF8caazmpRA_ccSTpGqu';
const USE_MOCKS = false;

// Реальный клиент создаётся только если подключена библиотека supabase-js
// <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
let supabaseClient = null;
if (!USE_MOCKS && window.supabase) {
  supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
}

/* -------------------------------------------------------------------------
   AUTH
   ------------------------------------------------------------------------- */

/**
 /**
 * Регистрация нового пользователя.
 * @param {{email:string, password:string, name:string, role:'founder'|'specialist'|'investor'|'admin'}} data
 */
async function signUp(data) {
  if (USE_MOCKS) return MockDB.signUp(data);

  const { data: authData, error } = await supabaseClient.auth.signUp({
    email: data.email,
    password: data.password,
  });
  if (error) throw error;

  // Профиль хранится в отдельной таблице `profiles`, привязанной к auth.users по id
  const { error: profileError } = await supabaseClient.from('profiles').insert({
    id: authData.user.id,
    name: data.name,
    role: data.role,
    status: 'active',
  });
  if (profileError) throw profileError;

  // Редирект после успешной регистрации
  window.location.href = 'profile.html';
  
  return authData;
}

/**
 * Вход пользователя по email/паролю.
 * @param {{email:string, password:string}} data
 */
async function signIn(data) {
  if (USE_MOCKS) return MockDB.signIn(data);

  const { data: authData, error } = await supabaseClient.auth.signInWithPassword({
    email: data.email,
    password: data.password,
  });
  if (error) throw error;
  
  // Редирект после успешного входа
  window.location.href = 'profile.html';
  
  return authData;
}
/** Выход из аккаунта. */
async function signOut() {
  if (USE_MOCKS) return MockDB.signOut();
  const { error } = await supabaseClient.auth.signOut();
  if (error) throw error;
}

/** Получить текущего залогиненного пользователя (профиль + роль). */
async function getCurrentUser() {
  if (USE_MOCKS) return MockDB.getCurrentUser();

  const { data: { session } } = await supabaseClient.auth.getSession();
  if (!session) return null;
  const { data, error } = await supabaseClient
    .from('profiles')
    .select('*')
    .eq('id', session.user.id)
    .single();
  if (error) throw error;
  return data;
}

/* -------------------------------------------------------------------------
   STARTUPS
   ------------------------------------------------------------------------- */

/** Получить список стартапов с опциональными фильтрами. */
async function getStartups(filters = {}) {
  if (USE_MOCKS) return MockDB.getStartups(filters);

  let query = supabaseClient.from('startups').select('*').eq('status', 'approved');
  if (filters.category) query = query.eq('category', filters.category);
  if (filters.hiringRole) query = query.contains('open_roles', [filters.hiringRole]);
  const { data, error } = await query;
  if (error) throw error;
  return data;
}

/** Создать новый стартап (роль founder). */
async function addStartup(startup) {
  if (USE_MOCKS) return MockDB.addStartup(startup);
  const { data, error } = await supabaseClient.from('startups').insert(startup).select().single();
  if (error) throw error;
  return data;
}

/** Изменить статус стартапа: 'approved' | 'pending' | 'rejected' (для модерации). */
async function updateStartupStatus(startupId, status) {
  if (USE_MOCKS) return MockDB.updateStartupStatus(startupId, status);
  const { error } = await supabaseClient.from('startups').update({ status }).eq('id', startupId);
  if (error) throw error;
}

async function deleteStartup(startupId) {
  if (USE_MOCKS) return MockDB.deleteStartup(startupId);
  const { error } = await supabaseClient.from('startups').delete().eq('id', startupId);
  if (error) throw error;
}

/* -------------------------------------------------------------------------
   ОТКЛИКИ (applications) — специалист откликается на стартап
   ------------------------------------------------------------------------- */

/** Отправить отклик специалиста на стартап. */
async function sendApplication({ startupId, specialistId, message }) {
  if (USE_MOCKS) return MockDB.sendApplication({ startupId, specialistId, message });
  const { data, error } = await supabaseClient
    .from('applications')
    .insert({ startup_id: startupId, specialist_id: specialistId, message, status: 'pending' })
    .select().single();
  if (error) throw error;
  return data;
}

/** Изменить статус отклика: 'accepted' | 'rejected'. */
async function updateApplicationStatus(applicationId, status) {
  if (USE_MOCKS) return MockDB.updateApplicationStatus(applicationId, status);
  const { error } = await supabaseClient.from('applications').update({ status }).eq('id', applicationId);
  if (error) throw error;
}

/* -------------------------------------------------------------------------
   ИНВЕСТИЦИИ
   ------------------------------------------------------------------------- */

/** Инвестор вкладывает сумму в стартап. */
async function invest({ startupId, investorId, amount }) {
  if (USE_MOCKS) return MockDB.invest({ startupId, investorId, amount });
  const { data, error } = await supabaseClient
    .from('investments')
    .insert({ startup_id: startupId, investor_id: investorId, amount })
    .select().single();
  if (error) throw error;
  return data;
}

/* -------------------------------------------------------------------------
   АДМИНИСТРИРОВАНИЕ
   ------------------------------------------------------------------------- */

async function getAllUsers() {
  if (USE_MOCKS) return MockDB.getAllUsers();
  const { data, error } = await supabaseClient.from('profiles').select('*');
  if (error) throw error;
  return data;
}

async function setUserBanned(userId, banned) {
  if (USE_MOCKS) return MockDB.setUserBanned(userId, banned);
  const { error } = await supabaseClient.from('profiles').update({ banned }).eq('id', userId);
  if (error) throw error;
}

async function setUserRole(userId, role) {
  if (USE_MOCKS) return MockDB.setUserRole(userId, role);
  const { error } = await supabaseClient.from('profiles').update({ role }).eq('id', userId);
  if (error) throw error;
}

async function getPlatformStats() {
  if (USE_MOCKS) return MockDB.getPlatformStats();
  const [{ count: users }, { count: startups }, { count: applications }] = await Promise.all([
    supabaseClient.from('profiles').select('*', { count: 'exact', head: true }),
    supabaseClient.from('startups').select('*', { count: 'exact', head: true }),
    supabaseClient.from('applications').select('*', { count: 'exact', head: true }),
  ]);
  return { users, startups, applications };
}

/* =========================================================================
   SQL-СХЕМА ДЛЯ SUPABASE (выполнить в SQL Editor проекта)
   -------------------------------------------------------------------------
   create table profiles (
     id uuid primary key references auth.users(id) on delete cascade,
     name text,
     role text check (role in ('founder','specialist','investor','admin')),
     status text default 'active',
     banned boolean default false,
     avatar_seed text,
     bio text,
     skills text[],
     balance numeric default 0,
     created_at timestamp default now()
   );

   create table startups (
     id uuid primary key default gen_random_uuid(),
     founder_id uuid references profiles(id),
     name text, tagline text, description text,
     category text, open_roles text[],
     raised numeric default 0, goal numeric default 0,
     status text default 'pending', -- pending | approved | rejected
     created_at timestamp default now()
   );

   create table applications (
     id uuid primary key default gen_random_uuid(),
     startup_id uuid references startups(id),
     specialist_id uuid references profiles(id),
     message text,
     status text default 'pending', -- pending | accepted | rejected
     created_at timestamp default now()
   );

   create table investments (
     id uuid primary key default gen_random_uuid(),
     startup_id uuid references startups(id),
     investor_id uuid references profiles(id),
     amount numeric,
     created_at timestamp default now()
   );

   -- Row Level Security (пример):
   alter table profiles enable row level security;
   create policy "Users can view all profiles" on profiles for select using (true);
   create policy "Users can update own profile" on profiles for update using (auth.uid() = id);
   ========================================================================= */
