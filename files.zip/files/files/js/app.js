/* =========================================================================
   app.js — общая логика, подключаемая на всех страницах:
   навигация, тосты, ролевые бейджи, аватары, guard-функции для доступа.
   ========================================================================= */

const ROLE_META = {
  founder:    { label: 'Стартап',     badge: 'badge-founder',    color: '#C8FF3D' },
  specialist: { label: 'Специалист',  badge: 'badge-specialist', color: '#3DDC97' },
  investor:   { label: 'Инвестор',    badge: 'badge-investor',   color: '#FFB13D' },
  admin:      { label: 'Админ',       badge: 'badge-admin',      color: '#FF5D5D' },
};

function roleBadgeHTML(role) {
  const m = ROLE_META[role] || { label: role, badge: 'badge-neutral' };
  return `<span class="badge ${m.badge}"><span class="badge-dot"></span>${m.label}</span>`;
}

function initials(name = '?') {
  return name.split(' ').map((p) => p[0]).slice(0, 2).join('').toUpperCase();
}

function avatarStyle(seed = '') {
  const colors = ['#C8FF3D', '#3DDC97', '#FFB13D', '#7CA8FF', '#FF8AD8'];
  let h = 0;
  for (const c of seed) h += c.charCodeAt(0);
  const bg = colors[h % colors.length];
  return `background:${bg}22; color:${bg}; border:1px solid ${bg}55;`;
}

/* ---------------- Toasts ---------------- */
function ensureToastStack() {
  let stack = document.querySelector('.toast-stack');
  if (!stack) {
    stack = document.createElement('div');
    stack.className = 'toast-stack';
    document.body.appendChild(stack);
  }
  return stack;
}
function showToast(message, type = 'default') {
  const stack = ensureToastStack();
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  stack.appendChild(el);
  setTimeout(() => {
    el.style.opacity = '0';
    el.style.transition = 'opacity .2s';
    setTimeout(() => el.remove(), 200);
  }, 3200);
}

/* ---------------- Nav ---------------- */
async function renderNav(activePage = '') {
  const mount = document.getElementById('nav-mount');
  if (!mount) return;
  const user = await getCurrentUser();

  const links = [
    { href: 'index.html', label: 'Главная', key: 'index' },
    { href: 'catalog.html', label: 'Каталог', key: 'catalog' },
  ];
  if (user) links.push({ href: 'profile.html', label: 'Кабинет', key: 'profile' });
  if (user && user.role === 'admin') links.push({ href: 'admin.html', label: 'Админка', key: 'admin' });

  const linksHTML = links.map(
    (l) => `<a href="${l.href}" class="${activePage === l.key ? 'active' : ''}">${l.label}</a>`
  ).join('');

  const actionsHTML = user
    ? `<span class="mono" style="font-size:13px;color:var(--text-dim);">${user.name}</span>
       ${roleBadgeHTML(user.role)}
       <button class="btn btn-ghost btn-sm" id="logout-btn">Выйти</button>`
    : `<a href="auth.html" class="btn btn-ghost btn-sm">Войти</a>
       <a href="auth.html?mode=signup" class="btn btn-primary btn-sm">Регистрация</a>`;

  mount.innerHTML = `
    <nav class="nav">
      <div class="nav-inner">
        <a href="index.html" class="brand"><span class="brand-mark">L</span>LaunchGrid</a>
        <div class="nav-links" id="nav-links">${linksHTML}</div>
        <div class="nav-actions">${actionsHTML}</div>
        <button class="nav-toggle" id="nav-toggle" aria-label="Меню">☰</button>
      </div>
    </nav>`;

  document.getElementById('nav-toggle')?.addEventListener('click', () => {
    document.getElementById('nav-links').classList.toggle('open');
  });
  document.getElementById('logout-btn')?.addEventListener('click', async () => {
    await signOut();
    showToast('Вы вышли из аккаунта');
    setTimeout(() => (window.location.href = 'index.html'), 400);
  });

  return user;
}

/** Защищает страницу: если не залогинен — редирект на auth.html. Возвращает пользователя. */
async function requireAuth() {
  const user = await getCurrentUser();
  if (!user) {
    window.location.href = 'auth.html';
    return null;
  }
  return user;
}

/** Защищает страницу для конкретной роли (например, 'admin'). */
async function requireRole(role) {
  const user = await requireAuth();
  if (!user) return null;
  if (user.role !== role) {
    document.body.innerHTML = `
      <div class="container" style="padding:80px 24px; text-align:center;">
        <h2 style="font-size:24px;">Доступ ограничен</h2>
        <p style="color:var(--text-dim); margin-top:10px;">Эта страница доступна только роли «${ROLE_META[role]?.label || role}».</p>
        <a href="profile.html" class="btn btn-primary" style="margin-top:20px;">В личный кабинет</a>
      </div>`;
    return null;
  }
  return user;
}

/** Рендерит панель вкладок (используется в profile.js и admin.js). */
function tabbarHTML(tabs) {
  return `<div class="tabbar">${tabs.map((t, i) => `<button class="tabbtn ${i === 0 ? 'active' : ''}" data-tab="${t.key}">${t.label}</button>`).join('')}</div>`;
}
function wireTabs(root) {
  root.querySelectorAll('.tabbtn').forEach((btn) => {
    btn.addEventListener('click', () => {
      root.querySelectorAll('.tabbtn').forEach((b) => b.classList.remove('active'));
      root.querySelectorAll('.tabpanel').forEach((p) => p.classList.remove('active'));
      btn.classList.add('active');
      root.querySelector(`.tabpanel[data-panel="${btn.dataset.tab}"]`).classList.add('active');
    });
  });
}

function formatMoney(n) {
  return `$${Number(n || 0).toLocaleString('ru-RU')}`;
}
function timeAgo(dateStr) {
  const d = new Date(dateStr);
  const days = Math.max(0, Math.floor((Date.now() - d.getTime()) / 86400000));
  if (days === 0) return 'сегодня';
  if (days === 1) return 'вчера';
  return `${days} дн. назад`;
}
