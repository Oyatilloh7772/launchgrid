/* =========================================================================
   admin.js — доступна только роли admin (проверяется через requireRole)
   ========================================================================= */

async function renderStats(root) {
  const stats = await getPlatformStats();
  root.innerHTML = `
    <div class="grid grid-3">
      <div class="stat-tile"><div class="num">${stats.users}</div><div class="lbl">Пользователей</div></div>
      <div class="stat-tile"><div class="num">${stats.startups}</div><div class="lbl">Стартапов всего</div></div>
      <div class="stat-tile"><div class="num">${stats.pendingStartups}</div><div class="lbl">На модерации</div></div>
      <div class="stat-tile"><div class="num">${stats.applications}</div><div class="lbl">Откликов отправлено</div></div>
      <div class="stat-tile"><div class="num">${formatMoney(stats.invested)}</div><div class="lbl">Всего инвестировано</div></div>
    </div>`;
}

async function renderUsersTable(root) {
  const users = await getAllUsers();
  root.innerHTML = `
    <div class="table-wrap">
      <table>
        <thead><tr><th>Пользователь</th><th>Email</th><th>Роль</th><th>Статус</th><th>Действия</th></tr></thead>
        <tbody>
          ${users.map((u) => `
            <tr>
              <td class="strong">${u.name}</td>
              <td class="mono">${u.email}</td>
              <td>
                <select class="input" style="padding:6px 10px;font-size:13px;" data-role-select="${u.id}" ${u.role === 'admin' ? 'disabled' : ''}>
                  ${['founder', 'specialist', 'investor', 'admin'].map((r) => `<option value="${r}" ${r === u.role ? 'selected' : ''}>${ROLE_META[r].label}</option>`).join('')}
                </select>
              </td>
              <td>${u.banned ? `<span class="badge badge-admin"><span class="badge-dot"></span>Забанен</span>` : `<span class="badge badge-specialist"><span class="badge-dot"></span>Активен</span>`}</td>
              <td>
                ${u.role === 'admin' ? '<span style="color:var(--text-faint);font-size:13px;">—</span>' : `
                <button class="btn btn-sm ${u.banned ? 'btn-teal' : 'btn-danger'}" data-ban="${u.id}">${u.banned ? 'Разбанить' : 'Забанить'}</button>`}
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>`;

  root.querySelectorAll('[data-role-select]').forEach((sel) => {
    sel.addEventListener('change', async () => {
      await setUserRole(sel.dataset.roleSelect, sel.value);
      showToast('Роль обновлена', 'success');
    });
  });
  root.querySelectorAll('[data-ban]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const users2 = await getAllUsers();
      const u = users2.find((x) => x.id === btn.dataset.ban);
      await setUserBanned(u.id, !u.banned);
      showToast(u.banned ? 'Пользователь разбанен' : 'Пользователь забанен', u.banned ? 'success' : 'error');
      await renderUsersTable(root);
    });
  });
}

async function renderModeration(root) {
  const startups = await MockDB.getAllStartupsRaw();
  const pending = startups.filter((s) => s.status !== 'approved');
  const approved = startups.filter((s) => s.status === 'approved');

  const rowsHTML = (list, showActions) => list.map((s) => `
    <tr>
      <td class="strong">${s.name}</td>
      <td>${s.category}</td>
      <td>${s.status === 'approved' ? `<span class="badge badge-specialist"><span class="badge-dot"></span>Опубликован</span>` : s.status === 'pending' ? `<span class="badge badge-neutral"><span class="badge-dot"></span>На модерации</span>` : `<span class="badge badge-admin"><span class="badge-dot"></span>Отклонён</span>`}</td>
      <td>${formatMoney(s.raised)} / ${formatMoney(s.goal)}</td>
      <td>
        ${showActions ? `
          <button class="btn btn-teal btn-sm" data-approve="${s.id}">Одобрить</button>
          <button class="btn btn-danger btn-sm" data-delete="${s.id}">Удалить</button>
        ` : `<button class="btn btn-danger btn-sm" data-delete="${s.id}">Удалить</button>`}
      </td>
    </tr>
  `).join('');

  root.innerHTML = `
    <h3 style="font-size:15px;color:var(--text-dim);margin-bottom:12px;">Ожидают модерации (${pending.length})</h3>
    <div class="table-wrap" style="margin-bottom:28px;">
      <table>
        <thead><tr><th>Стартап</th><th>Категория</th><th>Статус</th><th>Раунд</th><th>Действия</th></tr></thead>
        <tbody>${pending.length ? rowsHTML(pending, true) : `<tr><td colspan="5" style="text-align:center;color:var(--text-faint);">Нет заявок на модерацию</td></tr>`}</tbody>
      </table>
    </div>
    <h3 style="font-size:15px;color:var(--text-dim);margin-bottom:12px;">Опубликованные (${approved.length})</h3>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Стартап</th><th>Категория</th><th>Статус</th><th>Раунд</th><th>Действия</th></tr></thead>
        <tbody>${approved.length ? rowsHTML(approved, false) : `<tr><td colspan="5" style="text-align:center;color:var(--text-faint);">Пока нет опубликованных стартапов</td></tr>`}</tbody>
      </table>
    </div>`;

  root.querySelectorAll('[data-approve]').forEach((btn) => btn.addEventListener('click', async () => {
    await updateStartupStatus(btn.dataset.approve, 'approved');
    showToast('Стартап одобрен', 'success');
    await renderModeration(root);
    await renderStats(document.getElementById('stats-mount'));
  }));
  root.querySelectorAll('[data-delete]').forEach((btn) => btn.addEventListener('click', async () => {
    if (!confirm('Удалить стартап без возможности восстановления?')) return;
    await deleteStartup(btn.dataset.delete);
    showToast('Стартап удалён');
    await renderModeration(root);
    await renderStats(document.getElementById('stats-mount'));
  }));
}

(async () => {
  const user = await requireRole('admin');
  if (!user) return;
  await renderNav('admin');

  const root = document.getElementById('admin-root');
  root.innerHTML = `
    <div class="section-head">
      <div><h2>Админ-панель</h2><p>Пользователи, модерация и статистика платформы</p></div>
    </div>
    <div id="stats-mount" style="margin-bottom:36px;"></div>
    ${tabbarHTML([{ key: 'moderation', label: 'Модерация стартапов' }, { key: 'users', label: 'Пользователи' }])}
    <div class="tabpanel active" data-panel="moderation"><div id="moderation-mount"></div></div>
    <div class="tabpanel" data-panel="users"><div id="users-mount"></div></div>
  `;
  wireTabs(root);

  await renderStats(document.getElementById('stats-mount'));
  await renderModeration(document.getElementById('moderation-mount'));
  await renderUsersTable(document.getElementById('users-mount'));
})();
