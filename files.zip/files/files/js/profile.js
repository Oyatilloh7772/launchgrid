/* =========================================================================
   profile.js — личный кабинет, вид зависит от user.role
   ========================================================================= */

let PROFILE_USER = null;

function headerBlock(user) {
  return `
    <div class="card" style="display:flex;align-items:center;gap:18px;flex-wrap:wrap;margin-bottom:32px;">
      <div class="startup-logo" style="width:56px;height:56px;font-size:20px;${avatarStyle(user.name)}">${initials(user.name)}</div>
      <div style="flex:1;min-width:180px;">
        <h2 style="font-size:20px;">${user.name}</h2>
        <p class="mono" style="font-size:12px;color:var(--text-faint);margin-top:4px;">${user.email}</p>
      </div>
      ${roleBadgeHTML(user.role)}
    </div>`;
}

/* ================= SPECIALIST ================= */
async function renderSpecialist(root, user) {
  const applications = await MockDB.getApplicationsForSpecialist(user.id);
  const statusLabel = { pending: ['ожидает', 'badge-neutral'], accepted: ['принят', 'badge-specialist'], rejected: ['отклонён', 'badge-admin'] };

  root.innerHTML = headerBlock(user) + `
    ${tabbarHTML([{ key: 'portfolio', label: 'Портфолио' }, { key: 'history', label: 'История откликов' }])}
    <div class="tabpanel active" data-panel="portfolio">
      <div class="grid grid-2">
        <div class="card">
          <h3 style="font-size:16px;margin-bottom:16px;">Статус поиска</h3>
          <div class="field">
            <label for="status-select">Текущий статус</label>
            <select class="input" id="status-select">
              <option value="looking" ${user.status === 'looking' ? 'selected' : ''}>🟢 В поиске</option>
              <option value="not_looking" ${user.status === 'not_looking' ? 'selected' : ''}>⚪ Не ищу проект</option>
            </select>
          </div>
          <button class="btn btn-teal btn-block" id="save-status">Сохранить статус</button>
        </div>
        <div class="card">
          <h3 style="font-size:16px;margin-bottom:16px;">О себе и навыки</h3>
          <div class="field">
            <label for="bio-field">Био</label>
            <textarea class="input" id="bio-field">${user.bio || ''}</textarea>
          </div>
          <div class="field">
            <label for="skills-field">Навыки (через запятую)</label>
            <input class="input" id="skills-field" value="${(user.skills || []).join(', ')}">
          </div>
          <button class="btn btn-primary btn-block" id="save-portfolio">Сохранить портфолио</button>
        </div>
      </div>
    </div>
    <div class="tabpanel" data-panel="history">
      <div id="history-list"></div>
    </div>
  `;
  wireTabs(root);

  const historyMount = root.querySelector('#history-list');
  if (!applications.length) {
    historyMount.innerHTML = `<div class="empty"><h3>Пока нет откликов</h3><p>Перейдите в каталог и предложите себя стартапу.</p></div>`;
  } else {
    historyMount.innerHTML = applications.map((a) => {
      const [label, cls] = statusLabel[a.status];
      return `
        <div class="app-row">
          <div class="app-avatar" style="${avatarStyle(a.startup?.name || '?')}">${initials(a.startup?.name || '?')}</div>
          <div class="app-meta">
            <div class="name">${a.startup?.name || 'Стартап удалён'}</div>
            <div class="sub">${a.message} · ${timeAgo(a.createdAt)}</div>
          </div>
          <span class="badge ${cls}"><span class="badge-dot"></span>${label}</span>
        </div>`;
    }).join('');
  }

  root.querySelector('#save-status').addEventListener('click', async () => {
    const status = root.querySelector('#status-select').value;
    await MockDB.updateProfile(user.id, { status });
    showToast('Статус обновлён', 'success');
  });
  root.querySelector('#save-portfolio').addEventListener('click', async () => {
    const bio = root.querySelector('#bio-field').value.trim();
    const skills = root.querySelector('#skills-field').value.split(',').map((s) => s.trim()).filter(Boolean);
    await MockDB.updateProfile(user.id, { bio, skills });
    showToast('Портфолио сохранено', 'success');
  });
}

/* ================= FOUNDER ================= */
async function renderFounder(root, user) {
  const myStartups = await MockDB.getStartupsForFounder(user.id);
  const applications = await MockDB.getApplicationsForFounder(user.id);
  const statusChip = { approved: ['опубликован', 'badge-specialist'], pending: ['на модерации', 'badge-neutral'], rejected: ['отклонён', 'badge-admin'] };

  root.innerHTML = headerBlock(user) + `
    ${tabbarHTML([{ key: 'startups', label: 'Мои проекты' }, { key: 'applications', label: 'Входящие отклики' }])}
    <div class="tabpanel active" data-panel="startups">
      <div class="card" style="margin-bottom:24px;">
        <h3 style="font-size:16px;margin-bottom:16px;">Добавить проект</h3>
        <div class="grid grid-2">
          <div class="field"><label for="ns-name">Название</label><input class="input" id="ns-name" placeholder="Nova Pay"></div>
          <div class="field"><label for="ns-category">Категория</label><input class="input" id="ns-category" placeholder="Fintech"></div>
        </div>
        <div class="field"><label for="ns-tagline">Короткое описание (tagline)</label><input class="input" id="ns-tagline" placeholder="Одна яркая фраза о продукте"></div>
        <div class="field"><label for="ns-desc">Полное описание</label><textarea class="input" id="ns-desc" placeholder="Что делает продукт, для кого, какая тяга уже есть"></textarea></div>
        <div class="grid grid-2">
          <div class="field"><label for="ns-roles">Открытые роли (через запятую)</label><input class="input" id="ns-roles" placeholder="Дизайнер, Backend"></div>
          <div class="field"><label for="ns-goal">Цель по инвестициям ($)</label><input class="input" type="number" id="ns-goal" placeholder="50000"></div>
        </div>
        <button class="btn btn-primary btn-block" id="add-startup-btn">Отправить на модерацию</button>
      </div>
      <div id="my-startups-list" class="grid grid-2"></div>
    </div>
    <div class="tabpanel" data-panel="applications">
      <div id="apps-list"></div>
    </div>
  `;
  wireTabs(root);

  const startupsMount = root.querySelector('#my-startups-list');
  if (!myStartups.length) {
    startupsMount.innerHTML = `<div class="empty" style="grid-column:1/-1;"><h3>Проектов пока нет</h3><p>Заполните форму выше, чтобы опубликовать первый.</p></div>`;
  } else {
    startupsMount.innerHTML = myStartups.map((s) => {
      const [label, cls] = statusChip[s.status] || ['—', 'badge-neutral'];
      return `
      <div class="card startup-card">
        <div class="startup-card-top">
          <div class="startup-logo" style="${avatarStyle(s.name)}">${initials(s.name)}</div>
          <span class="badge ${cls}"><span class="badge-dot"></span>${label}</span>
        </div>
        <div class="startup-name">${s.name}</div>
        <div class="startup-tag">${s.tagline}</div>
        <div class="startup-stats">
          <div class="stat"><b>${formatMoney(s.raised)}</b><span>Собрано</span></div>
          <div class="stat"><b>${formatMoney(s.goal)}</b><span>Цель</span></div>
        </div>
      </div>`;
    }).join('');
  }

  root.querySelector('#add-startup-btn').addEventListener('click', async () => {
    const name = root.querySelector('#ns-name').value.trim();
    const category = root.querySelector('#ns-category').value.trim();
    const tagline = root.querySelector('#ns-tagline').value.trim();
    const description = root.querySelector('#ns-desc').value.trim();
    const openRoles = root.querySelector('#ns-roles').value.split(',').map((s) => s.trim()).filter(Boolean);
    const goal = Number(root.querySelector('#ns-goal').value) || 0;
    if (!name || !tagline) { showToast('Укажите как минимум название и tagline', 'error'); return; }
    try {
      await addStartup({ founderId: user.id, name, category: category || 'Other', tagline, description, openRoles, goal });
      showToast('Проект отправлен на модерацию', 'success');
      await renderFounder(root, user);
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  const appsMount = root.querySelector('#apps-list');
  if (!applications.length) {
    appsMount.innerHTML = `<div class="empty"><h3>Пока нет откликов</h3><p>Как только специалисты откликнутся на ваш проект, они появятся здесь.</p></div>`;
  } else {
    appsMount.innerHTML = applications.map((a) => `
      <div class="app-row">
        <div class="app-avatar" style="${avatarStyle(a.specialist?.name || '?')}">${initials(a.specialist?.name || '?')}</div>
        <div class="app-meta">
          <div class="name">${a.specialist?.name || 'Пользователь удалён'} <span style="color:var(--text-faint);font-weight:400;">→ ${a.startup?.name}</span></div>
          <div class="sub">${a.message} · ${timeAgo(a.createdAt)}</div>
        </div>
        ${a.status === 'pending' ? `
          <div class="app-actions">
            <button class="btn btn-teal btn-sm" data-accept="${a.id}">Принять</button>
            <button class="btn btn-danger btn-sm" data-reject="${a.id}">Отклонить</button>
          </div>` : `<span class="badge ${a.status === 'accepted' ? 'badge-specialist' : 'badge-admin'}"><span class="badge-dot"></span>${a.status === 'accepted' ? 'принят' : 'отклонён'}</span>`}
      </div>
    `).join('');

    appsMount.querySelectorAll('[data-accept]').forEach((btn) => btn.addEventListener('click', async () => {
      await updateApplicationStatus(btn.dataset.accept, 'accepted');
      showToast('Отклик принят', 'success');
      await renderFounder(root, user);
    }));
    appsMount.querySelectorAll('[data-reject]').forEach((btn) => btn.addEventListener('click', async () => {
      await updateApplicationStatus(btn.dataset.reject, 'rejected');
      showToast('Отклик отклонён');
      await renderFounder(root, user);
    }));
  }
}

/* ================= INVESTOR ================= */
async function renderInvestor(root, user) {
  const investments = await MockDB.getInvestmentsForInvestor(user.id);
  const totalInvested = investments.reduce((sum, i) => sum + i.amount, 0);

  root.innerHTML = headerBlock(user) + `
    <div class="grid grid-3" style="margin-bottom:32px;">
      <div class="stat-tile"><div class="num">${formatMoney(user.balance)}</div><div class="lbl">Доступный баланс</div></div>
      <div class="stat-tile"><div class="num">${formatMoney(totalInvested)}</div><div class="lbl">Всего вложено</div></div>
      <div class="stat-tile"><div class="num">${investments.length}</div><div class="lbl">Проектов в портфеле</div></div>
    </div>
    ${tabbarHTML([{ key: 'portfolio', label: 'Мои инвестиции' }])}
    <div class="tabpanel active" data-panel="portfolio">
      <div id="invest-list" class="grid grid-2"></div>
    </div>
  `;
  wireTabs(root);

  const mount = root.querySelector('#invest-list');
  if (!investments.length) {
    mount.innerHTML = `<div class="empty" style="grid-column:1/-1;"><h3>Портфель пуст</h3><p>Загляните в <a href="catalog.html" style="color:var(--signal);">каталог</a>, чтобы найти первый проект для инвестиции.</p></div>`;
  } else {
    mount.innerHTML = investments.map((i) => `
      <div class="card startup-card">
        <div class="startup-card-top">
          <div class="startup-logo" style="${avatarStyle(i.startup?.name || '?')}">${initials(i.startup?.name || '?')}</div>
          <span class="chip">${timeAgo(i.createdAt)}</span>
        </div>
        <div class="startup-name">${i.startup?.name || 'Проект удалён'}</div>
        <div class="startup-tag">${i.startup?.tagline || ''}</div>
        <div class="startup-stats">
          <div class="stat"><b>${formatMoney(i.amount)}</b><span>Ваш вклад</span></div>
          <div class="stat"><b>${formatMoney(i.startup?.raised || 0)}</b><span>Собрано всего</span></div>
        </div>
      </div>
    `).join('');
  }
}

/* ================= ADMIN (shortcut card) ================= */
function renderAdminShortcut(root, user) {
  root.innerHTML = headerBlock(user) + `
    <div class="card" style="text-align:center;padding:48px;">
      <h3 style="font-size:18px;margin-bottom:10px;">У вас роль администратора</h3>
      <p style="color:var(--text-dim);margin-bottom:20px;">Управление пользователями, модерация стартапов и статистика доступны в админ-панели.</p>
      <a href="admin.html" class="btn btn-primary">Перейти в админ-панель</a>
    </div>`;
}

(async () => {
  const user = await requireAuth();
  if (!user) return;
  await renderNav('profile');
  PROFILE_USER = user;
  const root = document.getElementById('profile-root');

  if (user.role === 'specialist') await renderSpecialist(root, user);
  else if (user.role === 'founder') await renderFounder(root, user);
  else if (user.role === 'investor') await renderInvestor(root, user);
  else if (user.role === 'admin') renderAdminShortcut(root, user);
})();
