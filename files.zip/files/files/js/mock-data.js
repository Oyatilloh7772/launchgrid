/* =========================================================================
   mock-data.js
   Локальная "база данных" на localStorage — эмулирует Supabase, пока
   реальный бэкенд не подключен (см. USE_MOCKS в supabase.js).
   Структура полностью совпадает со схемой из supabase.js, поэтому
   переключение на реальный бэкенд не потребует правок в UI-коде.
   ========================================================================= */

const LS_KEY = 'launchgrid_db_v1';
const LS_SESSION = 'launchgrid_session_v1';

function uid(prefix = 'id') {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}

const SEED = {
  users: [
    { id: 'u_founder1', email: 'nova@demo.io', password: '123456', name: 'Алина Ким', role: 'founder', status: 'active', banned: false, bio: 'Основатель, ex-product в финтехе.', skills: [], balance: 0, createdAt: '2026-02-01' },
    { id: 'u_founder2', email: 'orbit@demo.io', password: '123456', name: 'Марк Ли', role: 'founder', status: 'active', banned: false, bio: 'Строю логистику для стран СНГ.', skills: [], balance: 0, createdAt: '2026-03-11' },
    { id: 'u_spec1', email: 'designer@demo.io', password: '123456', name: 'Диана Юсупова', role: 'specialist', status: 'looking', banned: false, bio: 'Product-дизайнер, 4 года в стартапах, Figma / дизайн-системы.', skills: ['UI/UX', 'Figma', 'Branding'], balance: 0, createdAt: '2026-01-20' },
    { id: 'u_spec2', email: 'dev@demo.io', password: '123456', name: 'Родион Ким', role: 'specialist', status: 'not_looking', banned: false, bio: 'Fullstack, React / Node, любит перформанс.', skills: ['React', 'Node.js', 'PostgreSQL'], balance: 0, createdAt: '2026-04-02' },
    { id: 'u_inv1', email: 'invest@demo.io', password: '123456', name: 'Тимур Расулов', role: 'investor', status: 'active', banned: false, bio: 'Ангел-инвестор, чек 5–50k$.', skills: [], balance: 42000, createdAt: '2025-12-15' },
    { id: 'u_admin', email: 'admin@demo.io', password: 'admin123', name: 'Admin', role: 'admin', status: 'active', banned: false, bio: '', skills: [], balance: 0, createdAt: '2025-11-01' },
  ],
  startups: [
    { id: 's1', founderId: 'u_founder1', name: 'Nova Pay', tagline: 'Мгновенные P2P-переводы в Центральной Азии', description: 'Платёжная платформа для быстрых и дешёвых переводов между Узбекистаном, Казахстаном и Кыргызстаном. MVP запущен, 3 000 активных пользователей.', category: 'Fintech', openRoles: ['Дизайнер', 'Backend'], raised: 18000, goal: 60000, status: 'approved', createdAt: '2026-02-05' },
    { id: 's2', founderId: 'u_founder2', name: 'Orbit Logistics', tagline: 'SaaS для управления доставкой последней мили', description: 'Инструмент маршрутизации и трекинга для курьерских служб. Уже используют 12 компаний.', category: 'Logistics', openRoles: ['Frontend', 'Sales'], raised: 42000, goal: 80000, status: 'approved', createdAt: '2026-03-12' },
    { id: 's3', founderId: 'u_founder1', name: 'Vanta Health', tagline: 'AI-триаж симптомов для клиник', description: 'Чат-бот первичного приёма, снижает нагрузку на регистратуру на 30%.', category: 'HealthTech', openRoles: ['Дизайнер', 'ML-инженер'], raised: 5000, goal: 50000, status: 'approved', createdAt: '2026-05-01' },
    { id: 's4', founderId: 'u_founder2', name: 'Krono', tagline: 'Планировщик смен для ритейла', description: 'Автоматическое составление расписаний с учётом трудового законодательства.', category: 'Productivity', openRoles: ['Backend'], raised: 0, goal: 30000, status: 'pending', createdAt: '2026-06-20' },
  ],
  applications: [
    { id: 'a1', startupId: 's1', specialistId: 'u_spec1', message: 'Готова помочь с дизайн-системой и онбордингом.', status: 'pending', createdAt: '2026-06-01' },
    { id: 'a2', startupId: 's2', specialistId: 'u_spec2', message: 'Есть опыт с картами и real-time трекингом на React.', status: 'accepted', createdAt: '2026-04-18' },
    { id: 'a3', startupId: 's3', specialistId: 'u_spec1', message: 'Интересен нейминг и UI для медицинского продукта.', status: 'rejected', createdAt: '2026-05-10' },
  ],
  investments: [
    { id: 'i1', startupId: 's2', investorId: 'u_inv1', amount: 12000, createdAt: '2026-04-01' },
    { id: 'i2', startupId: 's1', investorId: 'u_inv1', amount: 8000, createdAt: '2026-05-15' },
  ],
};

function loadDB() {
  const raw = localStorage.getItem(LS_KEY);
  if (!raw) {
    localStorage.setItem(LS_KEY, JSON.stringify(SEED));
    return JSON.parse(JSON.stringify(SEED));
  }
  return JSON.parse(raw);
}
function saveDB(db) {
  localStorage.setItem(LS_KEY, JSON.stringify(db));
}
function delay(ms = 250) {
  return new Promise((res) => setTimeout(res, ms));
}

const MockDB = {
  /* ---------------- AUTH ---------------- */
  async signUp({ email, password, name, role }) {
    await delay();
    const db = loadDB();
    if (db.users.some((u) => u.email === email)) {
      throw new Error('Пользователь с таким email уже зарегистрирован.');
    }
    const user = {
      id: uid('u'), email, password, name, role,
      status: role === 'specialist' ? 'looking' : 'active',
      banned: false, bio: '', skills: [],
      balance: role === 'investor' ? 10000 : 0,
      createdAt: new Date().toISOString().slice(0, 10),
    };
    db.users.push(user);
    saveDB(db);
    localStorage.setItem(LS_SESSION, user.id);
    return { user };
  },

  async signIn({ email, password }) {
    await delay();
    const db = loadDB();
    const user = db.users.find((u) => u.email === email && u.password === password);
    if (!user) throw new Error('Неверный email или пароль.');
    if (user.banned) throw new Error('Аккаунт заблокирован администратором.');
    localStorage.setItem(LS_SESSION, user.id);
    return { user };
  },

  async signOut() {
    await delay(100);
    localStorage.removeItem(LS_SESSION);
  },

  async getCurrentUser() {
    const id = localStorage.getItem(LS_SESSION);
    if (!id) return null;
    const db = loadDB();
    return db.users.find((u) => u.id === id) || null;
  },

  /* ---------------- STARTUPS ---------------- */
  async getStartups(filters = {}) {
    await delay();
    const db = loadDB();
    let list = db.startups.filter((s) => s.status === 'approved');
    if (filters.category) list = list.filter((s) => s.category === filters.category);
    if (filters.hiringRole) list = list.filter((s) => s.openRoles.includes(filters.hiringRole));
    if (filters.query) {
      const q = filters.query.toLowerCase();
      list = list.filter((s) => s.name.toLowerCase().includes(q) || s.tagline.toLowerCase().includes(q));
    }
    return list.map((s) => ({ ...s, founder: db.users.find((u) => u.id === s.founderId) }));
  },

  async getAllStartupsRaw() {
    await delay();
    return loadDB().startups;
  },

  async addStartup(startup) {
    await delay();
    const db = loadDB();
    const s = {
      id: uid('s'), status: 'pending', raised: 0, createdAt: new Date().toISOString().slice(0, 10),
      openRoles: [], ...startup,
    };
    db.startups.push(s);
    saveDB(db);
    return s;
  },

  async updateStartupStatus(startupId, status) {
    await delay();
    const db = loadDB();
    const s = db.startups.find((x) => x.id === startupId);
    if (s) s.status = status;
    saveDB(db);
    return s;
  },

  async deleteStartup(startupId) {
    await delay();
    const db = loadDB();
    db.startups = db.startups.filter((s) => s.id !== startupId);
    saveDB(db);
  },

  /* ---------------- APPLICATIONS ---------------- */
  async sendApplication({ startupId, specialistId, message }) {
    await delay();
    const db = loadDB();
    const app = { id: uid('a'), startupId, specialistId, message, status: 'pending', createdAt: new Date().toISOString().slice(0, 10) };
    db.applications.push(app);
    saveDB(db);
    return app;
  },

  async updateApplicationStatus(applicationId, status) {
    await delay();
    const db = loadDB();
    const app = db.applications.find((a) => a.id === applicationId);
    if (app) app.status = status;
    saveDB(db);
    return app;
  },

  async getApplicationsForSpecialist(specialistId) {
    await delay();
    const db = loadDB();
    return db.applications
      .filter((a) => a.specialistId === specialistId)
      .map((a) => ({ ...a, startup: db.startups.find((s) => s.id === a.startupId) }));
  },

  async getApplicationsForFounder(founderId) {
    await delay();
    const db = loadDB();
    const myStartupIds = db.startups.filter((s) => s.founderId === founderId).map((s) => s.id);
    return db.applications
      .filter((a) => myStartupIds.includes(a.startupId))
      .map((a) => ({
        ...a,
        startup: db.startups.find((s) => s.id === a.startupId),
        specialist: db.users.find((u) => u.id === a.specialistId),
      }));
  },

  /* ---------------- INVESTMENTS ---------------- */
  async invest({ startupId, investorId, amount }) {
    await delay();
    const db = loadDB();
    const investor = db.users.find((u) => u.id === investorId);
    if (!investor) throw new Error('Инвестор не найден.');
    if (investor.balance < amount) throw new Error('Недостаточно средств на балансе.');
    investor.balance -= amount;
    const startup = db.startups.find((s) => s.id === startupId);
    if (startup) startup.raised = (startup.raised || 0) + amount;
    const inv = { id: uid('i'), startupId, investorId, amount, createdAt: new Date().toISOString().slice(0, 10) };
    db.investments.push(inv);
    saveDB(db);
    return inv;
  },

  async getInvestmentsForInvestor(investorId) {
    await delay();
    const db = loadDB();
    return db.investments
      .filter((i) => i.investorId === investorId)
      .map((i) => ({ ...i, startup: db.startups.find((s) => s.id === i.startupId) }));
  },

  /* ---------------- ADMIN ---------------- */
  async getAllUsers() {
    await delay();
    return loadDB().users;
  },

  async setUserBanned(userId, banned) {
    await delay();
    const db = loadDB();
    const u = db.users.find((x) => x.id === userId);
    if (u) u.banned = banned;
    saveDB(db);
    return u;
  },

  async setUserRole(userId, role) {
    await delay();
    const db = loadDB();
    const u = db.users.find((x) => x.id === userId);
    if (u) u.role = role;
    saveDB(db);
    return u;
  },

  async getPlatformStats() {
    await delay();
    const db = loadDB();
    return {
      users: db.users.length,
      startups: db.startups.length,
      applications: db.applications.length,
      invested: db.investments.reduce((sum, i) => sum + i.amount, 0),
      pendingStartups: db.startups.filter((s) => s.status === 'pending').length,
    };
  },

  /* ---------------- PROFILE ---------------- */
  async updateProfile(userId, patch) {
    await delay();
    const db = loadDB();
    const u = db.users.find((x) => x.id === userId);
    if (u) Object.assign(u, patch);
    saveDB(db);
    return u;
  },

  async getStartupsForFounder(founderId) {
    await delay();
    const db = loadDB();
    return db.startups.filter((s) => s.founderId === founderId);
  },
};

// Небольшие демо-аккаунты для быстрого входа (показаны на auth.html)
const DEMO_ACCOUNTS = [
  { role: 'Стартап', email: 'nova@demo.io', password: '123456' },
  { role: 'Специалист', email: 'designer@demo.io', password: '123456' },
  { role: 'Инвестор', email: 'invest@demo.io', password: '123456' },
  { role: 'Админ', email: 'admin@demo.io', password: 'admin123' },
];
