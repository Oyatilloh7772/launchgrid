# LaunchGrid — платформа для стартапов, специалистов и инвесторов

## Структура проекта

```
/startup-platform
├── index.html          — Главная (hero, сеть ролей, популярные стартапы)
├── auth.html            — Вход / Регистрация с выбором роли
├── profile.html         — Личный кабинет (вид зависит от роли)
├── catalog.html         — Каталог стартапов с фильтрами
├── admin.html           — Админ-панель (только роль admin)
├── css/
│   └── style.css        — Вся вёрстка и дизайн-система (переменные, компоненты)
├── js/
│   ├── supabase.js       — Клиент Supabase + все backend-функции + SQL-схема
│   ├── mock-data.js      — Локальная "БД" на localStorage (пока USE_MOCKS = true)
│   ├── app.js            — Общее: навигация, тосты, guard-функции, форматтеры
│   ├── profile.js        — Логика личного кабинета (founder/specialist/investor/admin)
│   └── admin.js          — Логика админ-панели
└── README.md
```

## Как это работает сейчас (демо-режим)

`USE_MOCKS = true` в `js/supabase.js` — все функции (`signIn`, `signUp`, `addStartup`,
`sendApplication`, `invest` и т.д.) пишут и читают данные из `localStorage`
через `MockDB` в `js/mock-data.js`. Это значит:

- Данные переживают перезагрузку страницы (сохраняются в браузере).
- Есть готовые демо-аккаунты (показаны на странице входа):
  founder — `nova@demo.io / 123456`, specialist — `designer@demo.io / 123456`,
  investor — `invest@demo.io / 123456`, admin — `admin@demo.io / admin123`.

## Как подключить настоящий Supabase

1. Создайте проект на [supabase.com](https://supabase.com) и выполните SQL-схему
   из комментария в конце `js/supabase.js` (таблицы `profiles`, `startups`,
   `applications`, `investments`).
2. Подключите библиотеку клиента в `<head>` каждой HTML-страницы:
   ```html
   <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
   ```
   (подключить до `js/supabase.js`).
3. В `js/supabase.js` укажите:
   ```js
   const SUPABASE_URL = 'https://ваш-проект.supabase.co';
   const SUPABASE_ANON_KEY = 'ваш-anon-key';
   const USE_MOCKS = false;
   ```
4. Готово — весь UI (`index.html`, `catalog.html`, `profile.html`, `admin.html`,
   `auth.html`) продолжит работать без изменений, потому что он вызывает только
   функции из `supabase.js` (`signIn`, `getStartups`, `invest` и т.д.), а не
   напрямую `MockDB`.

> Единственное место, где UI обращается к `MockDB` напрямую — это несколько
> вспомогательных выборок в `profile.js`/`admin.js` (например,
> `getApplicationsForFounder`, `getInvestmentsForInvestor`,
> `getAllStartupsRaw`). При переходе на реальный бэкенд замените их на
> аналогичные Supabase-запросы с `.select()` + `join`/`.eq()` — принцип тот же.

## Роли

| Роль        | Возможности                                                            |
|-------------|-------------------------------------------------------------------------|
| founder     | Публикует стартапы, видит входящие отклики, принимает/отклоняет их     |
| specialist  | Редактирует портфолио и статус, откликается на стартапы из каталога    |
| investor    | Видит баланс, инвестирует в стартапы из каталога, видит свой портфель   |
| admin       | Модерирует стартапы, управляет пользователями (роль/бан), видит статистику |

## Дизайн

Тёмная палитра (`--ink #0B0E14`) с тремя ролевыми акцентами: lime `#C8FF3D`
(founder), teal `#3DDC97` (specialist), amber `#FFB13D` (investor).
Заголовки — Space Grotesk, текст — Inter, данные/деньги/ID — IBM Plex Mono.
Сигнатурный элемент — SVG-диаграмма сети из трёх ролей на главной странице.
